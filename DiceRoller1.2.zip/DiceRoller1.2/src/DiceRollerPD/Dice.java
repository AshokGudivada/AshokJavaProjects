package DiceRollerPD;
import java.util.Random;


import DiceRollerException.NumberOfDiceRangeException; 
import DiceRollerException.NumberOfFaceRangeException; 

public class Dice {
//  initialization
	private int[] freq;//the history
	private String[] sFreq;// the history in string form for printing
	public int freqValue;// no of rolls
	private int numberFace;
	private int die;
	
	/*public Dice(int numberFace)
	{
		freq = new int[numberFace];
		sFreq = new String[numberFace];
		this.numberFace = numberFace;
		freqValue=0;
		
	}*/
	public Dice(int numberFaces) throws NumberOfDiceRangeException
	{
		try {
			setNumberFaces( numberFaces);
		} catch (NumberOfFaceRangeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		freq = new int[numberFace];
		sFreq = new String[numberFace];
		freqValue=0;
		
	}

	private void setNumberFaces(int numberFace) throws 	
	NumberOfFaceRangeException
	{
		if (numberFace <=0)  
		{
			NumberOfFaceRangeException exception = new NumberOfFaceRangeException("Number of faces must be greater than zero");
			throw exception;
		}
		else
		{
			this.numberFace = numberFace;
		}
	}
	
	

    public int rollDie(){
    	die =(int)(Math.random()* numberFace)+1;
    	
    	freq[die-1]++;
    	freqValue++;
 
    	return die;
    }
	
    public int [] getFreq(){
    	return freq;
    }
    
    public String [] getSFreq(){
    	return sFreq;
    }
    
    
    public String freqString(){
    	String Str = "Dice: #face: "+numberFace+" TotalRolls: "+freqValue+"\n";
    	for(int i=0; i < numberFace; i++ ){
    		Str += " "+(i+1);
    	}
    		Str += "\n";
    		
    	for(int i=0; i < numberFace; i++ ){
    		Str += " "+ freq[i];
    	}
    	return Str;
    	
    }
    
    public String toString(){
    	String str = "Die :"+die;
    	return str;
    }

}
