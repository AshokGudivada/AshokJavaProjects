package DiceRollerException;

public class DiceRollException extends Exception {
///
	
	public DiceRollException() {
        // TODO Auto-generated constructor stub
    }

    public DiceRollException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public DiceRollException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public DiceRollException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }


}
