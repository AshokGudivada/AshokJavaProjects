package DiceRollerException;

import java.util.*;
import javax.swing.*;
public class NumberOfDiceRangeException extends Exception 
{
	 NumberOfDiceRangeException(String message)
	 {
	super(message);
	 }

}
