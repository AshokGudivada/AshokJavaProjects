package DiceRollerException;

import DiceRollerPD.DiceBag;

public class DiceRollerBagException extends Exception {
	/**
	 * 
	 */
	
	/*int numberOfFaces;
	int numberOfDice;
	DiceBag bag;
	
	try 
	{
		bag = new DiceBag(numberOfFaces,numberOfDice);
	}
	catch (NumberOfFacesRangeException exception)
	{
		errorMessage = exception.getMessage();
		errorMessageLabel.setText(errorMessage);
		diceRollerLabel.setText ("Total: Error");
		return;
	}
		catch (NumberOfDiceRangeException exception)
	{
		errorMessage = exception.getMessage();
		errorMessageLabel.setText(errorMessage);
		diceRollerLabel.setText ("Total: Error");
		return;
	}*/


}
