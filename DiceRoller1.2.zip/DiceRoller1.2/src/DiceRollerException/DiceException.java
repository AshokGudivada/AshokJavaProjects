package DiceRollerException;

public class DiceException {
	/*int numberFaces;
	public Die(int numberFaces) throws 	NumberOfFacesRangeException
	{
		this.setNumberFaces(numberFaces);
		if (Die.randomGen == null)
		{
			randomGen = new Random();
		}
	}
*/
}
