package DiceRollerUI;
import DiceRollerPD.Dice;
import DiceRollerPD.DiceBag;
import DiceRollerTest.DiceBagTest;
import DiceRollerTest.DiceTest;

/*public class Test {
	public static void main (String[] args){
		int noFace = 6;
		int noDice = 2;
		int noRoll = 100;
		int resultRollDie;
		
		// Test Case 1
		System.out.println("Test Case 1\n");
		Dice dieTest1;
		dieTest1 = new Dice(noFace);
		System.out.println("Dice Face Test of "+noRoll+"rolls with "+noFace+"faces");
		for (int i=0; i < noRoll; i++){
		resultRollDie = dieTest1.rollDie();
		System.out.println(i+" : " + resultRollDie);
		
		}
		
		System.out.println("\n \nTest Case 2\n");
		DiceTest dieTest;
		dieTest = new DiceTest();
		dieTest.testDieFrq(noFace, noRoll);
		// Test Case 2
		
		
		// Test Case 3\
		noRoll = 5;
		System.out.println("\n \nTest Case 3\n");
		System.out.println("DiceBag Test of "+noDice+" dice"+" with "+noFace+"faces"+"and rolls "+noRoll);
		DiceBagTest diceBag1 = new DiceBagTest();
		diceBag1.testRollBag(noFace, noDice,noRoll);
	
		//
		
	}
}
*/