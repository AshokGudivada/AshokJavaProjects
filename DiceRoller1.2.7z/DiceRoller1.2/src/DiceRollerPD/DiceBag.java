package DiceRollerPD;
import java.util.Arrays;

import DiceRollerException.NumberOfDiceRangeException;
import DiceRollerException.NumberOfFaceRangeException;

public class DiceBag {
	private Dice [] dices;
	private int totalBag = 0;
	private String totalBagStr = "";
	private int noDices;
	private int faces;
	
	//
	
	///
	
	public DiceBag(int faces, int noDices) throws 	NumberOfFaceRangeException, NumberOfDiceRangeException{
		this.noDices = noDices;
		this.faces = faces;
		dices = new Dice [noDices];
		for (int i=0; i < noDices; i++){
			dices[i]= new Dice(faces);
		}                                                                                                                                              
	}
	/*
	public Die(int numberFaces) throws 	NumberOfFacesRangeException
	{
		this.setNumberFaces(numberFaces);
		if (Die.randomGen == null)
		{
			randomGen = new Random();
		}
	}

	*/
	public void rollBag(){
		int tm;
		totalBagStr = "";
		totalBag = 0;
		for (int i=0; i < noDices; i++){
				tm = dices[i].rollDie();
				
				totalBag = totalBag + tm;
				totalBagStr = totalBagStr+" "+tm;
			}
				
		}
		
	
    
    public String toString(){
    	String str = "Total : "+totalBag+" Die : "+totalBagStr;
    	System.out.println(str);
    	return str;
    }
	
}
