package DiceRollerException;
import java.util.*;
import javax.swing.*;
public class NumberOfFaceRangeException extends Exception 
{
	public NumberOfFaceRangeException (String message){
		super(message);
	}
}
