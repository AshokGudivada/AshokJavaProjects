package DiceRollerUI;
import javax.swing.JFrame;

public class DiceRollerFrame extends JFrame {

	/**
	 * Create the frame.
	 */
	public DiceRollerFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Dice Roller");
		getContentPane().add(new DiceRollerPanel());		
	}
}

