package DiceRollerUI;
import javax.swing.JFrame;

public class DiceRollerStartUI {

	public static void main(String[] args) {
		
		JFrame frame = new DiceRollerFrame();
		frame.pack();		// set the size based on content
		frame.setVisible(true);// so we can see the frame
	}

}
