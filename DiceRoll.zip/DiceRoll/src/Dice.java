import java.util.Random; 
 

public class Dice {
	private int[] freq;
	private int numberFace;
	private int total;
	
	public Dice(int numberFace){
		freq = new int[numberFace];
		this.numberFace = numberFace;
		total=0;
	}

    public int rollDie(){
    	int die =(int)(Math.random()* numberFace);
    	freq[die]++;
    	total++;
    	return die+1;
    }
	
    public int [] getFreq(){
    	return freq;
    }
    
    public int getTotal(){
    	return total;
    }
    
    public String toString(){
    	String Str = "Dice: #face:"+numberFace+"TotalRolls\n";
    	for(int i=0; i < numberFace; i++ )
    		Str += " "+ freq[i];
    	return Str;
    	
    }
    

}
