import java.util.Arrays;

public class DiceBag {
	private Dice [] dices;
	private int totalBag = 0;
	private String totalBagStr = "";
	private int noDices;
	private int faces;
	
	
	public DiceBag(int faces, int noDices){
		this.noDices = noDices;
		this.faces = faces;
		dices = new Dice [noDices];
		for (int i=0; i < noDices; i++){
			dices[i]= new Dice(faces);
		}                                                                                                                                              
	}
	
	public void rollBag(int faces, int noDices){
		int tm;
		
		for (int i=0; i < noDices; i++){
			tm = dices[i].rollDie();
			System.out.println(dices[i]);
			totalBag = totalBag + tm;
			System.out.println("TB"+totalBag);
			totalBagStr = totalBagStr+" "+tm;	
		}
		System.out.println("totalBag = "+totalBag);
		System.out.println("totalBag = "+totalBagStr);
		  
	}
	
    public int [] totalFreq(){
    	int [] totalFreqR = new int [faces];
    	for (int i=0; i < noDices; i++){
    		for (int j=0; j < faces; j++)
    		{
    			totalFreqR[j]+= dices[i].getFreq()[j];
    		}
    	}
    	System.out.println(Arrays.toString(totalFreqR));
    	return totalFreqR;
    }
	
	
}
