
public class Test {
	public static void main (String[] args){
		int noFace = 4;
		int noDice = 5;
		DiceBag diceBag1 = new DiceBag(noFace, noDice);
		diceBag1.rollBag(noFace, noDice);
	}

}
