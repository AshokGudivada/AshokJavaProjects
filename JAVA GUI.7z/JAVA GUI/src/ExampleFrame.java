import javax.swing.JFrame;

public class ExampleFrame extends JFrame {

	/**
	 * Create the frame.
	 */
	public ExampleFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Dice Roller");
		getContentPane().add(new ExamplePanel());		
	}
}

