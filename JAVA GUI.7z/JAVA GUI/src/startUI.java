import javax.swing.JFrame;

public class startUI {

	public static void main(String[] args) {
		
		JFrame frame = new ExampleFrame();
		frame.pack();		// set the size based on content
		frame.setVisible(true);// so we can see the frame
	}

}
